class Dog < ApplicationRecord
	belongs_to :location, required: false
  has_many :stalls, dependent: :destroy 
  has_many :dogsitters, through: :stalls
end
