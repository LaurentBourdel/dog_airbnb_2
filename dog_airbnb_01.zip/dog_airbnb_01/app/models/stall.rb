class Stall < ApplicationRecord
	belongs_to :dogsitter, required: false
  belongs_to :dog, required: false
  belongs_to :location, required: false
end
