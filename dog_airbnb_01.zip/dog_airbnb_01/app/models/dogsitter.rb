class Dogsitter < ApplicationRecord
	belongs_to :location, required: false
  has_many :stalls, dependent: :destroy 
  has_many :dogs, through: :stalls
end
