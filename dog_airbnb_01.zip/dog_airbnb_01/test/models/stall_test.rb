require 'test_helper'

class StallTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
